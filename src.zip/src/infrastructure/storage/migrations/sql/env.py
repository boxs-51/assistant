import asyncio
from logging.config import fileConfig

from sqlalchemy import pool
from sqlalchemy.engine import Connection
from sqlalchemy.ext.asyncio import async_engine_from_config

from alembic import context
from infrastructure.storage.models.sql.chat_data import attachment
from infrastructure.storage.models.sql.chat_data import project
from infrastructure.storage.models.sql.user_data import api_key, application, member, oauth_account, organization, pending_registration
from infrastructure.storage.models.sql.user_data import permission

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Interpret the config file for Python logging.
# This line sets up loggers basically.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# add your model's MetaData object here
# for 'autogenerate' support
# from myapp import mymodel
# target_metadata = mymodel.Base.metadata

# --- THAY ĐỔI QUAN TRỌNG ---
# Import Base từ model của chúng ta để Alembic có thể "thấy" được các table
from infrastructure.storage.models.sql.user_data import (
    user
)
from infrastructure.storage.models.sql.base import Base
from infrastructure.storage.models.sql.chat_data import (
    session
) 
target_metadata = Base.metadata

# --- CẤU HÌNH DATABASE URL ---
# Lấy URL từ cấu hình của ứng dụng thay vì hardcode
# Tạm thời chúng ta sẽ hardcode URL của SQLite để đơn giản hóa
# Trong thực tế, bạn sẽ đọc từ file settings của ứng dụng
DB_URL = "sqlite+aiosqlite:///gateway_storage.db"
config.set_main_option("sqlalchemy.url", DB_URL)

# other values from the config, defined by the needs of env.py,
# can be acquired:
# my_important_option = config.get_main_option("my_important_option")
# ... etc.


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode.

    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well.  By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the
    script output.

    """
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection: Connection) -> None:
    context.configure(connection=connection, target_metadata=target_metadata)

    with context.begin_transaction():
        context.run_migrations()


async def run_async_migrations() -> None:
    """In this scenario we need to create an Engine
    and associate a connection with the context.

    """
    connectable = async_engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)

    await connectable.dispose()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode."""
    asyncio.run(run_async_migrations())

if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()

#alembic revision --autogenerate -m "commit"
#alembic upgrade head